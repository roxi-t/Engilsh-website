const input = "3 5";
const [a, b] = input.split(' ').map(Number);
const sum = a + b;
console.log(sum);
